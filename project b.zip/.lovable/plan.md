## Plan (modifications to `src/routes/index.tsx`)

### 1. Thèmes prédéfinis
- Remplacer **Charcoal**, **Black Ivory**, **Black Slate** par 3 thèmes fond noir vifs :
  - "Matrix" (`#000`, texte/dot `#22ff88`)
  - "Digital Blue" (`#03060f`, texte `#cfe9ff`, dot `#1e90ff`)
  - "Solar Orange" (`#0a0604`, texte `#ffd9b3`, dot `#ff7a18`)
- Remplacer **Ivory Calm**, **Sand Dune**, **Dusty Rose** par 3 thèmes fond sombre :
  - "Slate Deep" (bleu-gris foncé `#1b2433`, texte `#dde7f5`, dot `#7aa7d9`)
  - "Forest Night" (`#10231b`, texte `#d6efd9`, dot `#5fb27a`)
  - "Plum Noir" (`#1e1422`, texte `#ead7f0`, dot `#b07acb`)
- Supprimer le contour/box-shadow `:hover` sur `.theme-tile` (garder léger feedback opacity uniquement).
- `themesOpen` initial = `false`.
- Rapprocher la flèche du libellé "Thèmes prédéfinis" (chevron juste à droite du texte, pas en `justify-between`).
- Ajouter **3 cases supplémentaires** de thèmes perso (total : actuels + 3 slots vides supplémentaires).
- Remplacer le bouton "Enregistrer le thème actuel comme perso" par "Enregistrer le thème" avec icône `Save` (disquette, lucide) à gauche du libellé, même style que les boutons musique/image.

### 2. Saisie de date personnalisée
- Inputs : 3 champs séparés visuellement collés par "/", chaque champ accepte uniquement chiffres (`inputMode="numeric"`, regex `\d`).
- Auto-focus suivant : jour 2 chiffres → focus mois ; mois 2 chiffres → focus année ; année 4 chiffres → blur/valide.
- Validation intelligente : si jour > 31 ou > derniers jours du mois → clamp ; mois > 12 → clamp à 12 ; années raisonnables (1900-2100).

### 3. Polices personnalisées suivent la police générale
- Quand `fontFamily` (général) change, les champs `titleFont`, `subtitleFont`, `clockFont`, `progressFont`, `dateFont` qui n'ont pas été modifiés manuellement par l'utilisateur (= ils valent la précédente police générale) se mettent à jour automatiquement.
- Implémentation : dans le setter de fontFamily, comparer chaque sous-police à l'ancienne valeur ; si égale, la remplacer par la nouvelle.

### 4. Animations dot du jour
- Supprimer "Respiration" (`breathe`), la remplacer par "Pulse" (`pulse`) — un doux pulse opacity 0.6→1 sur 2.4s (différent de lighten et halo).
- Réduire visuellement le halo : ajouter slider de **rayon (1-12 px)** par animation (one shared `todayAnimRadius` ou par animation ; je choisis **un seul slider commun** "Rayon de l'animation" affiché lorsque animation ≠ off).
- Ajouter option **glow du jour activé/désactivé** (`todayDotGlow: boolean`, défaut `true`). Quand actif, le dot du jour reçoit le même `box-shadow` glow que les jours passés (avec multiplicateur de taille du dotGlow), **en plus** de l'animation choisie.

### 5. Sliders de taille pour glows
Remplacer les 3 boutons SM/MD/LG par une barre fine avec point déplaçable (même UX que slider taille police / flou image), pour :
- `titleGlowSize` (0-40 px de blur)
- `dotGlowSize` (multiplicateur 0.5-2.0)
- nouveau `todayAnimRadius`

Types passent de string à number ; conserver mapping rétrocompatible au chargement (sm=…, md=…, lg=…).

### 6. Profils
- Le placeholder/texte du champ d'édition lors de l'ajout d'un profil : couleur `opacity-50` + couleur identique à la bordure des bulles profil (gris discret), italic léger.

### 7. Barre de volume musique
- Slider placé **à gauche** du bouton `Volume2` (popover s'ouvre vers la gauche, aligné).
- Retirer le label "Volume — XX%".
- Retirer encadré/`border`/`bg-*`/`rounded`.
- Slider stylisé en CSS custom : track et thumb utilisent uniquement `config.textColor` (avec opacité), pas de bleu natif. `accent-color: textColor` + reset webkit-slider.

### 8. Annotation – activation rapide
- Au survol d'un dot (`onMouseEnter`), si l'utilisateur tape une touche caractère, ouvrir automatiquement le panneau d'annotation pour ce dot et préremplir avec la touche tapée (puis focus textarea).
- Implémentation : `hoveredDayKey` ref + global `keydown` listener qui ignore quand un input/textarea est déjà actif, ouvre `setSelectedDay(hovered)` et stocke la lettre initiale.

### 9. Couleurs personnalisées de la palette d'annotation
- Nouveau champ `annotationPalette: string[6]` dans config.
- Dans les paramètres : section "Palette d'annotation" avec 6 swatches, chacun ouvre l'input color natif (pipette) pour personnaliser.
- La fenêtre d'annotation utilise `config.annotationPalette` au lieu de la liste codée en dur.

### 10. Bug pipette annotation
- Investiguer : actuellement `pipetteRef.current?.click()` ouvre le sélecteur natif mais l'`onChange` du `<input type="color">` n'écrit pas sur le dot ciblé.
- Fix : s'assurer que l'`onChange` appelle `onSetDotColor(dayKey, e.target.value)` (et non setState local d'une autre couleur).

### 11. Animations du sous-titre (3 options + off)
- Ajouter `subtitleAnim: "off" | "shimmer" | "drift" | "glow-breath"`.
- Keyframes CSS lents/élégants (8-12s) :
  - **shimmer** : balayage gradient subtil sur le texte (`background-clip: text`, gradient anime `background-position`).
  - **drift** : translateY ±2px + opacity 0.7↔1, 10s ease-in-out.
  - **glow-breath** : text-shadow doux qui respire (0→6px) sur 9s.
- Sélecteur dans paramètres (4 boutons).

### Détails techniques
- Tous les changements dans `src/routes/index.tsx` + styles inline dans le bloc `<style>` existant.
- Aucun changement de logique métier ou backend.
- Mise à jour de `DEFAULT_CONFIG` et du chargement (rétrocompat : valeurs manquantes prennent les défauts).
- Aucun nouveau package nécessaire (icône `Save` déjà dans lucide-react).

Confirmes-tu ce plan ? Je passe ensuite à l'implémentation.