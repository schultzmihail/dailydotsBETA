import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Settings, X, Pipette, ChevronDown, ChevronUp, User, Plus, Music, Image as ImageIcon, Volume2, Save,
} from "lucide-react";

type TodayAnim = "off" | "lighten" | "pulse" | "halo";
type SubtitleAnim = "off" | "shimmer" | "drift" | "glow-breath";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Life Dots" },
      { name: "description", content: "Visualisez les jours écoulés depuis une date." },
    ],
  }),
  component: Index,
});

type Mode = "counter" | "dots";
type SizeKey = "xs" | "sm" | "md" | "lg" | "xl";

type Config = {
  mode: Mode;
  refDate: string;
  endDate: string;
  title: string;
  subtitle: string;
  template: string;
  bgColor: string;
  textColor: string;
  dotColor: string;
  useImage: boolean;
  bgImage: string;
  generalFont: string;
  fontFamily: string;
  titleFont: string;
  subtitleFont: string;
  clockFont: string;
  progressFont: string;
  dateFont: string;
  fontSize: number;
  bold: boolean;
  italic: boolean;
  customTheme: ThemeSnapshot | null;
  customThemes: (ThemeSnapshot | null)[];
  progressGradient: boolean;
  bgMusicEnabled: boolean;
  bgMusicName: string;
  calendarSize: SizeKey;
  blockSize: SizeKey;
  counterTextSize: SizeKey;
  annotations: Record<string, string>;
  dotColors: Record<string, string>;
  titleGlow: boolean;
  titleGlowRadius: number;
  titleGlowColor: string;
  dotGlow: boolean;
  dotGlowRadius: number;
  todayDotGlow: boolean;
  showDate: boolean;
  dateSize: SizeKey;
  todayAnim: TodayAnim;
  todayAnimRadius: number;
  subtitleAnim: SubtitleAnim;
  bgImageBlur: number;
  musicVolume: number;
  annotationPalette: string[];
};

type ThemeSnapshot = {
  bgColor: string;
  textColor: string;
  dotColor: string;
  fontFamily: string;
  titleFont: string;
  subtitleFont: string;
  clockFont: string;
};

type Profile = { id: string; name: string; config: Config };

const FONTS = [
  "System", "Inter", "Roboto", "Lora", "Playfair Display", "Montserrat",
  "Oswald", "Bebas Neue", "Pacifico", "Dancing Script", "Courier New", "Georgia",
  "Cormorant Garamond", "EB Garamond", "Crimson Text",
];

const GOOGLE_FONTS = new Set([
  "Inter", "Roboto", "Lora", "Playfair Display", "Montserrat",
  "Oswald", "Bebas Neue", "Pacifico", "Dancing Script",
  "Cormorant Garamond", "EB Garamond", "Crimson Text",
]);

const MONTH_ABBR = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

type Theme = { name: string; bgColor: string; textColor: string; dotColor: string };

const THEMES: Theme[] = [
  { name: "Paper White",    bgColor: "#ffffff", textColor: "#0a0a0a", dotColor: "#1a1a1a" },
  { name: "Pure Mono",      bgColor: "#000000", textColor: "#f5f5f5", dotColor: "#ffffff" },
  { name: "Matrix",         bgColor: "#000000", textColor: "#a8ffbf", dotColor: "#22ff88" },
  { name: "Digital Blue",   bgColor: "#03060f", textColor: "#cfe9ff", dotColor: "#1e90ff" },
  { name: "Solar Orange",   bgColor: "#0a0604", textColor: "#ffd9b3", dotColor: "#ff7a18" },
  { name: "Sage Garden",    bgColor: "#e8efe6", textColor: "#2d3a2c", dotColor: "#5a7a52" },
  { name: "Ocean Mist",     bgColor: "#dce8ee", textColor: "#1f3a48", dotColor: "#4e7d92" },
  { name: "Lavender Field", bgColor: "#e6e0ec", textColor: "#2f2840", dotColor: "#7a6aa0" },
  { name: "Slate Deep",     bgColor: "#1b2433", textColor: "#dde7f5", dotColor: "#7aa7d9" },
  { name: "Forest Night",   bgColor: "#10231b", textColor: "#d6efd9", dotColor: "#5fb27a" },
  { name: "Plum Noir",      bgColor: "#1e1422", textColor: "#ead7f0", dotColor: "#b07acb" },
];

const SIZE_MULT: Record<SizeKey, number> = { xs: 0.72, sm: 0.86, md: 1, lg: 1.18, xl: 1.4 };
const SIZE_LABELS: { key: SizeKey; label: string }[] = [
  { key: "xs", label: "Très petit" },
  { key: "sm", label: "Petit" },
  { key: "md", label: "Normal" },
  { key: "lg", label: "Grand" },
  { key: "xl", label: "Très grand" },
];

const TODAY_ANIM_OPTIONS: { key: TodayAnim; label: string }[] = [
  { key: "off", label: "Désactivée" },
  { key: "lighten", label: "Surbrillance" },
  { key: "pulse", label: "Pulse" },
  { key: "halo", label: "Halo" },
];

const SUBTITLE_ANIM_OPTIONS: { key: SubtitleAnim; label: string }[] = [
  { key: "off", label: "Aucune" },
  { key: "shimmer", label: "Shimmer" },
  { key: "drift", label: "Drift" },
  { key: "glow-breath", label: "Glow" },
];

const DEFAULT_PALETTE = ["#cfe8ff", "#d4f0d0", "#fff5c2", "#e8d9f4", "#ffd9b8", "#ff3b3b"];

const DEFAULT_CONFIG: Config = {
  mode: "dots",
  refDate: new Date(Date.now() - 86400000 * 90).toISOString().slice(0, 10),
  endDate: new Date(Date.now() + 86400000 * 275).toISOString().slice(0, 10),
  title: "Life Dots",
  subtitle: "Chaque point, un jour de vie",
  template: "Aujourd'hui, cela fait {jours} jours depuis la date fatidique",
  bgColor: "#000000",
  textColor: "#ede7d9",
  dotColor: "#c9b48a",
  useImage: false,
  bgImage: "",
  generalFont: "",
  fontFamily: "Playfair Display",
  titleFont: "Playfair Display",
  subtitleFont: "Inter",
  clockFont: "Inter",
  progressFont: "Inter",
  dateFont: "Inter",
  fontSize: 64,
  bold: false,
  italic: false,
  customTheme: null,
  customThemes: [null, null, null],
  progressGradient: true,
  bgMusicEnabled: false,
  bgMusicName: "",
  calendarSize: "md",
  blockSize: "md",
  counterTextSize: "md",
  annotations: {},
  dotColors: {},
  titleGlow: false,
  titleGlowRadius: 16,
  titleGlowColor: "#ffffff",
  dotGlow: true,
  dotGlowRadius: 1.0,
  todayDotGlow: true,
  showDate: true,
  dateSize: "md",
  todayAnim: "lighten",
  todayAnimRadius: 4,
  subtitleAnim: "off",
  bgImageBlur: 0,
  musicVolume: 0.7,
  annotationPalette: [...DEFAULT_PALETTE],
};

const PROFILES_KEY = "lifedots-profiles";
const LEGACY_KEY = "compteur-jours-config";

function uid() { return Math.random().toString(36).slice(2, 10); }

function loadProfiles(): { profiles: Profile[]; activeId: string } {
  if (typeof window === "undefined") {
    const p: Profile = { id: "default", name: "Profil 1", config: DEFAULT_CONFIG };
    return { profiles: [p], activeId: p.id };
  }
  try {
    const raw = localStorage.getItem(PROFILES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.profiles?.length) {
        parsed.profiles = parsed.profiles.map((p: Profile) => ({
          ...p,
          config: {
            ...DEFAULT_CONFIG,
            ...p.config,
            annotations: p.config?.annotations ?? {},
            dotColors: p.config?.dotColors ?? {},
          },
        }));
        return parsed;
      }
    }
    const legacy = localStorage.getItem(LEGACY_KEY);
    if (legacy) {
      const cfg = { ...DEFAULT_CONFIG, ...JSON.parse(legacy) };
      const p: Profile = { id: uid(), name: "Profil 1", config: cfg };
      return { profiles: [p], activeId: p.id };
    }
  } catch { /* ignore */ }
  const p: Profile = { id: uid(), name: "Profil 1", config: DEFAULT_CONFIG };
  return { profiles: [p], activeId: p.id };
}

function safeSaveProfiles(profiles: Profile[], activeId: string) {
  try {
    localStorage.setItem(PROFILES_KEY, JSON.stringify({ profiles, activeId }));
  } catch {
    try {
      const stripped = profiles.map((p) => ({ ...p, config: { ...p.config, bgImage: "" } }));
      localStorage.setItem(PROFILES_KEY, JSON.stringify({ profiles: stripped, activeId }));
    } catch { /* abandon */ }
  }
}

function daysSince(dateStr: string): number {
  const d = new Date(dateStr + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.floor((now.getTime() - d.getTime()) / 86400000);
}

type DayCell = {
  day: number;
  status: "past" | "today" | "future" | "empty";
  dateKey: string;
};

function ymd(y: number, m: number, d: number) {
  return `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

function buildMonths(refDateStr: string, endDateStr: string): { year: number; month: number; days: DayCell[] }[] {
  const ref = new Date(refDateStr + "T00:00:00");
  const end = new Date(endDateStr + "T00:00:00");
  if (isNaN(ref.getTime()) || isNaN(end.getTime()) || end < ref) return [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const months: { year: number; month: number; days: DayCell[] }[] = [];
  const cursor = new Date(ref.getFullYear(), ref.getMonth(), 1);
  const endCursor = new Date(end.getFullYear(), end.getMonth(), 1);

  while (cursor <= endCursor) {
    const y = cursor.getFullYear();
    const m = cursor.getMonth();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const startDay = y === ref.getFullYear() && m === ref.getMonth() ? ref.getDate() : 1;
    const endDay = y === end.getFullYear() && m === end.getMonth() ? end.getDate() : daysInMonth;
    const days: DayCell[] = [];
    for (let d = 1; d <= 31; d++) {
      if (d < startDay || d > endDay || d > daysInMonth) {
        days.push({ day: d, status: "empty", dateKey: "" });
        continue;
      }
      const date = new Date(y, m, d);
      let status: DayCell["status"] = "future";
      if (date.getTime() < today.getTime()) status = "past";
      else if (date.getTime() === today.getTime()) status = "today";
      days.push({ day: d, status, dateKey: ymd(y, m, d) });
    }
    months.push({ year: y, month: m, days });
    cursor.setMonth(cursor.getMonth() + 1);
  }
  return months;
}

function fontCss(name: string) {
  return name === "System" || !name ? "system-ui, -apple-system, sans-serif" : `"${name}", sans-serif`;
}

function isoToFr(iso: string): string {
  if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}
function frToIso(fr: string): string | null {
  const m = fr.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!m) return null;
  const d = m[1].padStart(2, "0");
  const mo = m[2].padStart(2, "0");
  const y = m[3];
  const test = new Date(`${y}-${mo}-${d}T00:00:00`);
  if (isNaN(test.getTime())) return null;
  return `${y}-${mo}-${d}`;
}

function formatDateFrLong(iso: string): string {
  try {
    const d = new Date(iso + "T00:00:00");
    return new Intl.DateTimeFormat("fr-FR", {
      weekday: "long", day: "numeric", month: "long", year: "numeric",
    }).format(d);
  } catch { return iso; }
}

function titleGlowCss(color: string, radius: number): string {
  const r = Math.max(0, radius);
  return `0 0 ${r * 0.6}px ${color}80, 0 0 ${r * 1.2}px ${color}60`;
}

function Index() {
  const [profiles, setProfiles] = useState<Profile[]>([{ id: "default", name: "Profil 1", config: DEFAULT_CONFIG }]);
  const [activeId, setActiveId] = useState<string>("default");
  const [loaded, setLoaded] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [hover, setHover] = useState(false);
  const [showProfiles, setShowProfiles] = useState(false);
  const [now, setNow] = useState(new Date());
  const [musicUrl, setMusicUrl] = useState<string>("");
  const [pendingNewProfile, setPendingNewProfile] = useState<string | null>(null);
  const [showVolume, setShowVolume] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const data = loadProfiles();
    setProfiles(data.profiles);
    setActiveId(data.activeId);
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) safeSaveProfiles(profiles, activeId);
  }, [profiles, activeId, loaded]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowSettings(false);
        setShowProfiles(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const activeProfile = profiles.find((p) => p.id === activeId) ?? profiles[0];
  const config = activeProfile?.config ?? DEFAULT_CONFIG;

  const setConfig = (c: Config) => {
    setProfiles((prev) => prev.map((p) => (p.id === activeId ? { ...p, config: c } : p)));
  };

  // Resolve fonts with generalFont override
  const gen = config.generalFont;
  const eff = {
    title: gen || config.titleFont,
    subtitle: gen || config.subtitleFont,
    clock: gen || config.clockFont,
    progress: gen || config.progressFont,
    date: gen || config.dateFont,
    body: gen || config.fontFamily,
  };

  useEffect(() => {
    const fontsToLoad = [...FONTS, gen].filter(Boolean);
    fontsToLoad.forEach((f) => {
      if (!GOOGLE_FONTS.has(f)) return;
      const id = `gf-${f.replace(/\s+/g, "-")}`;
      if (document.getElementById(id)) return;
      const link = document.createElement("link");
      link.id = id;
      link.rel = "stylesheet";
      link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(f)}:wght@400;700&display=swap`;
      document.head.appendChild(link);
    });
  }, [gen]);

  const days = useMemo(() => daysSince(config.refDate), [config.refDate]);
  const message = config.template.replace(/\{jours\}/g, String(days));
  const months = useMemo(
    () => (config.mode === "dots" ? buildMonths(config.refDate, config.endDate) : []),
    [config.mode, config.refDate, config.endDate]
  );

  const { progress, elapsed, remaining } = useMemo(() => {
    const ref = new Date(config.refDate + "T00:00:00").getTime();
    const end = new Date(config.endDate + "T00:00:00").getTime();
    const t = Date.now();
    if (!isFinite(ref) || !isFinite(end) || end <= ref) {
      return { progress: 0, elapsed: 0, remaining: 0 };
    }
    const totalDays = Math.round((end - ref) / 86400000);
    const elapsedDays = Math.max(0, Math.min(totalDays, Math.floor((t - ref) / 86400000)));
    return {
      progress: Math.max(0, Math.min(100, ((t - ref) / (end - ref)) * 100)),
      elapsed: elapsedDays,
      remaining: Math.max(0, totalDays - elapsedDays),
    };
  }, [config.refDate, config.endDate]);

  const hasBgImage = config.useImage && !!config.bgImage;
  const bgStyle: React.CSSProperties = hasBgImage
    ? { backgroundColor: config.bgColor }
    : { backgroundColor: config.bgColor };

  // Sync audio volume
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = config.musicVolume;
  }, [config.musicVolume, musicUrl]);

  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");

  const addProfile = () => {
    const np: Profile = { id: uid(), name: `Profil ${profiles.length + 1}`, config: { ...config, annotations: {}, dotColors: {} } };
    setProfiles([...profiles, np]);
    setActiveId(np.id);
    setPendingNewProfile(np.id);
  };
  const commitProfileName = (id: string, name: string) => {
    const trimmed = name.trim();
    if (trimmed) {
      setProfiles((prev) => prev.map((x) => (x.id === id ? { ...x, name: trimmed } : x)));
    }
    setPendingNewProfile(null);
  };

  const deleteProfile = (id: string) => {
    if (profiles.length <= 1) { alert("Vous devez garder au moins un profil."); return; }
    const next = profiles.filter((p) => p.id !== id);
    setProfiles(next);
    if (id === activeId) setActiveId(next[0].id);
  };

  const renameProfile = (id: string) => {
    const p = profiles.find((x) => x.id === id);
    if (!p) return;
    const name = prompt("Nouveau nom :", p.name);
    if (!name) return;
    setProfiles((prev) => prev.map((x) => (x.id === id ? { ...x, name } : x)));
  };

  const progressBg = config.progressGradient
    ? `linear-gradient(to right, ${config.textColor}10, ${config.textColor}30)`
    : `${config.textColor}25`;
  const progressFill = config.progressGradient
    ? `linear-gradient(to right, ${config.dotColor}50, ${config.dotColor})`
    : config.dotColor;

  const blockScale = SIZE_MULT[config.blockSize];
  const counterScale = SIZE_MULT[config.counterTextSize];
  const dateScale = SIZE_MULT[config.dateSize];

  const setAnnotation = (key: string, text: string) => {
    const next = { ...config.annotations };
    if (text.trim() === "") delete next[key]; else next[key] = text;
    setConfig({ ...config, annotations: next });
  };
  const setDotColor = (key: string, color: string | null) => {
    const next = { ...config.dotColors };
    if (color === null) delete next[key]; else next[key] = color;
    setConfig({ ...config, dotColors: next });
  };

  // Layout uses CSS `zoom` so the flex parent measures the scaled height naturally.


  const today = new Date();
  const todayIso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const todayLong = formatDateFrLong(todayIso);
  const todayCap = todayLong.charAt(0).toUpperCase() + todayLong.slice(1);

  return (
    <div className="relative min-h-screen w-full overflow-auto" style={bgStyle}>
      {hasBgImage && (
        <div
          aria-hidden
          className="fixed inset-0 pointer-events-none"
          style={{
            zIndex: 0,
            backgroundImage: `url(${config.bgImage})`,
            backgroundSize: "cover",
            backgroundPosition: "center center",
            backgroundRepeat: "no-repeat",
            filter: config.bgImageBlur > 0 ? `blur(${config.bgImageBlur}px)` : "none",
            transform: config.bgImageBlur > 0 ? "scale(1.06)" : "none",
          }}
        />
      )}
      {config.bgMusicEnabled && musicUrl && (
        <audio ref={audioRef} src={musicUrl} autoPlay loop />
      )}

      <div className="relative z-10 min-h-screen w-full flex flex-col items-center justify-center px-6 py-10 gap-6">
        <div
          className="text-center"
          style={{
            color: config.textColor,
            zoom: blockScale,
            width: "100%",
            maxWidth: 900,
          }}
        >
            <h1
              className="text-4xl md:text-5xl font-semibold tracking-tight"
              style={{
                fontFamily: fontCss(eff.title),
                textShadow: config.titleGlow ? titleGlowCss(config.titleGlowColor, config.titleGlowRadius) : "none",
              }}
            >
              {config.title}
            </h1>
            {config.subtitle && (
              <p
                className={`mt-2 text-sm md:text-base opacity-70 ${
                  config.subtitleAnim === "shimmer" ? "sub-shimmer"
                  : config.subtitleAnim === "drift" ? "sub-drift"
                  : config.subtitleAnim === "glow-breath" ? "sub-glow-breath"
                  : ""
                }`}
                style={{ fontFamily: fontCss(eff.subtitle) }}
              >
                {config.subtitle}
              </p>
            )}
            {config.showDate && (
              <p
                className="mt-2 opacity-75"
                style={{
                  fontFamily: fontCss(eff.date),
                  fontSize: `${14 * dateScale}px`,
                }}
              >
                {todayCap}
              </p>
            )}
            <p
              className="mt-1 text-sm md:text-base opacity-80 clock-text"
              style={{ fontFamily: fontCss(eff.clock) }}
            >
              <span className="clock-num">{hh}</span>
              <span className="clock-sep">:</span>
              <span className="clock-num">{mm}</span>
              <span className="clock-sep">:</span>
              <span className="clock-num">{ss}</span>
            </p>
            <div className="mt-4 w-full max-w-md mx-auto" style={{ fontFamily: fontCss(eff.progress) }}>
              <div className="flex items-center gap-3">
                <span className="text-xs opacity-70 tabular-nums shrink-0">{elapsed} jours écoulés</span>
                <div className="h-2 flex-1 rounded-full overflow-hidden" style={{ background: progressBg }}>
                  <div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: progressFill }} />
                </div>
                <span className="text-xs opacity-70 tabular-nums shrink-0">{remaining} jours restants</span>
              </div>
              <div className="mt-1 text-xs opacity-60 tabular-nums">{progress.toFixed(1)}%</div>
            </div>
        </div>


        {config.mode === "counter" ? (
          <h2
            className="text-center px-8 leading-tight select-none"
            style={{
              color: config.textColor,
              fontFamily: fontCss(eff.body),
              fontSize: `${config.fontSize * counterScale}px`,
              fontWeight: config.bold ? 700 : 400,
              fontStyle: config.italic ? "italic" : "normal",
              maxWidth: "90vw",
            }}
          >
            {message}
          </h2>
        ) : (
          <LifeDots
            months={months}
            dotColor={config.dotColor}
            labelColor={config.textColor}
            sizeKey={config.calendarSize}
            annotations={config.annotations}
            dotColors={config.dotColors}
            onSetAnnotation={setAnnotation}
            onSetDotColor={setDotColor}
            panelBg={config.bgColor}
            dotGlow={config.dotGlow}
            dotGlowRadius={config.dotGlowRadius}
            todayDotGlow={config.todayDotGlow}
            todayAnim={config.todayAnim}
            todayAnimRadius={config.todayAnimRadius}
            palette={config.annotationPalette}
          />

        )}
      </div>

      <div
        className="absolute top-0 right-0 h-16 z-30"
        style={{ width: showProfiles ? "100%" : "320px" }}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        <div className={`flex gap-2 justify-end items-start p-3 transition-opacity duration-200 ${hover || showProfiles ? "opacity-100" : "opacity-0"}`}>
          {showProfiles && (
            <div className="flex gap-2 items-start mr-1 profiles-fade">
              {profiles.map((p) => (
                <ProfileBubble
                  key={p.id}
                  profile={p}
                  active={p.id === activeId}
                  text={config.textColor}
                  editing={pendingNewProfile === p.id}
                  onClick={() => setActiveId(p.id)}
                  onDelete={() => deleteProfile(p.id)}
                  onRename={() => renameProfile(p.id)}
                  onCommitName={(n) => commitProfileName(p.id, n)}
                />
              ))}
              <button
                onClick={addProfile}
                className="w-9 h-9 rounded-full border flex items-center justify-center transition hover:scale-110"
                style={{ borderColor: `${config.textColor}50`, color: `${config.textColor}90`, background: "transparent" }}
                title="Ajouter un profil"
              >
                <Plus size={14} />
              </button>
            </div>
          )}
          {musicUrl && (
            <div className="flex items-center gap-2">
              {showVolume && (
                <input
                  type="range" min={0} max={100} value={Math.round(config.musicVolume * 100)}
                  onChange={(e) => setConfig({ ...config, musicVolume: Number(e.target.value) / 100 })}
                  className="slider-mono"
                  style={{ width: 110, color: config.textColor }}
                />
              )}
              <button
                onClick={() => setShowVolume((s) => !s)}
                className="w-9 h-9 rounded-full border flex items-center justify-center transition hover:scale-110"
                style={{ borderColor: `${config.textColor}60`, color: config.textColor, background: showVolume ? `${config.textColor}12` : "transparent" }}
                aria-label="Volume"
                title="Volume de la musique"
              >
                <Volume2 size={16} />
              </button>
            </div>
          )}
          <button
            onClick={() => setShowProfiles((s) => !s)}
            className="w-9 h-9 rounded-full border flex items-center justify-center transition hover:scale-110"
            style={{
              borderColor: `${config.textColor}60`,
              color: config.textColor,
              background: showProfiles ? `${config.textColor}12` : "transparent",
            }}
            aria-label="Profils"
            title="Profils"
          >
            <User size={16} />
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className="w-9 h-9 rounded-full border flex items-center justify-center transition hover:scale-110"
            style={{ borderColor: `${config.textColor}60`, color: config.textColor, background: "transparent" }}
            aria-label="Paramètres"
            title="Paramètres"
          >
            <Settings size={16} />
          </button>
          <button
            onClick={() => window.close()}
            className="w-9 h-9 rounded-full border flex items-center justify-center transition hover:scale-110"
            style={{ borderColor: `${config.textColor}60`, color: config.textColor, background: "transparent" }}
            aria-label="Fermer"
            title="Fermer"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {showSettings && (
        <SettingsPanel
          config={config}
          onChange={setConfig}
          onClose={() => setShowSettings(false)}
          onReset={() => setConfig(DEFAULT_CONFIG)}
          musicUrl={musicUrl}
          onMusicFile={(file) => {
            if (musicUrl) URL.revokeObjectURL(musicUrl);
            if (file) {
              const url = URL.createObjectURL(file);
              setMusicUrl(url);
              setConfig({ ...config, bgMusicName: file.name, bgMusicEnabled: true });
            } else {
              setMusicUrl("");
              setConfig({ ...config, bgMusicName: "", bgMusicEnabled: false });
            }
          }}
        />
      )}

      <style>{`
        .clock-text { font-variant-numeric: tabular-nums; }
        .clock-num { display: inline-block; width: 2ch; text-align: center; }
        .clock-sep {
          display: inline-block;
          width: 0.5ch;
          text-align: center;
          position: relative;
          top: -0.08em;
        }
        .profiles-fade { animation: fadeInLeft 220ms ease-out; }
        @keyframes fadeInLeft {
          from { opacity: 0; transform: translateX(8px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        .today-dot { transform: scale(1.25); }
        @keyframes todayLighten {
          0%, 100% { background-color: var(--dot); }
          50%      { background-color: color-mix(in oklab, var(--dot) 70%, white); }
        }
        .today-lighten { animation: todayLighten 2.4s ease-in-out infinite; }
        @keyframes todayPulse {
          0%, 100% { opacity: 1; filter: brightness(1); }
          50%      { opacity: 0.65; filter: brightness(1.25); }
        }
        .today-pulse { animation: todayPulse 2.2s ease-in-out infinite; }
        @keyframes todayHalo {
          0%   { box-shadow: 0 0 0 0 color-mix(in oklab, var(--dot) 75%, transparent); }
          70%  { box-shadow: 0 0 0 var(--anim-r, 6px) color-mix(in oklab, var(--dot) 0%, transparent); }
          100% { box-shadow: 0 0 0 0 color-mix(in oklab, var(--dot) 0%, transparent); }
        }
        .today-halo { animation: todayHalo 2.2s ease-out infinite; }
        .theme-tile { transition: opacity 150ms ease; }
        .theme-tile:hover { opacity: 0.92; }

        /* Subtitle animations */
        @keyframes subtShimmer {
          0%   { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
        .sub-shimmer {
          background-image: linear-gradient(90deg, currentColor 0%, currentColor 40%, color-mix(in oklab, currentColor 30%, white) 50%, currentColor 60%, currentColor 100%);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
          animation: subtShimmer 9s linear infinite;
        }
        @keyframes subtDrift {
          0%, 100% { transform: translateY(0); opacity: 0.7; }
          50%      { transform: translateY(-2px); opacity: 1; }
        }
        .sub-drift { animation: subtDrift 10s ease-in-out infinite; }
        @keyframes subtGlow {
          0%, 100% { text-shadow: 0 0 0 currentColor; }
          50%      { text-shadow: 0 0 6px currentColor; }
        }
        .sub-glow-breath { animation: subtGlow 9s ease-in-out infinite; }

        /* Custom slider (mono) */
        .slider-mono { -webkit-appearance: none; appearance: none; background: transparent; }
        .slider-mono::-webkit-slider-runnable-track {
          height: 3px; background: currentColor; opacity: 0.3; border-radius: 999px;
        }
        .slider-mono::-moz-range-track {
          height: 3px; background: currentColor; opacity: 0.3; border-radius: 999px;
        }
        .slider-mono::-webkit-slider-thumb {
          -webkit-appearance: none; appearance: none;
          width: 14px; height: 14px; border-radius: 999px;
          background: currentColor; margin-top: -5.5px; border: none;
        }
        .slider-mono::-moz-range-thumb {
          width: 14px; height: 14px; border-radius: 999px;
          background: currentColor; border: none;
        }
      `}</style>
    </div>
  );
}

function ProfileBubble({
  profile, active, text, editing, onClick, onDelete, onRename, onCommitName,
}: {
  profile: Profile;
  active: boolean;
  text: string;
  editing: boolean;
  onClick: () => void;
  onDelete: () => void;
  onRename: () => void;
  onCommitName: (n: string) => void;
}) {
  const [hover, setHover] = useState(false);
  const [name, setName] = useState(profile.name);
  useEffect(() => { setName(profile.name); }, [profile.name]);
  const initial = profile.name.trim().charAt(0).toUpperCase() || "?";
  return (
    <div
      className="relative flex flex-col items-center"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <button
        onClick={onClick}
        onDoubleClick={onRename}
        className="w-9 h-9 rounded-full flex items-center justify-center transition hover:scale-110"
        style={{
          background: active ? `${text}14` : "transparent",
          color: `${text}80`,
          border: `1px solid ${text}55`,
          fontSize: "11px",
          fontWeight: 500,
        }}
        title={`${profile.name} (double-clic pour renommer)`}
      >
        {initial}
      </button>
      {hover && !editing && (
        <button
          onClick={onDelete}
          className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center"
          style={{ background: "transparent", color: `${text}80`, border: `1px solid ${text}50` }}
          title="Supprimer ce profil"
        >
          <X size={8} />
        </button>
      )}
      {editing && (
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          onBlur={() => onCommitName(name)}
          onKeyDown={(e) => {
            if (e.key === "Enter") onCommitName(name);
            if (e.key === "Escape") onCommitName(profile.name);
          }}
          className="mt-1 px-2 py-0.5 text-xs rounded outline-none placeholder:italic placeholder:opacity-60"
          style={{
            background: "transparent",
            color: text,
            border: `1px solid ${text}55`,
            width: 80,
            textAlign: "center",
            fontStyle: name ? "normal" : "italic",
            opacity: name ? 1 : 0.7,
          }}
          placeholder="Nom du profil…"
        />
      )}
    </div>
  );
}

function LifeDots({
  months, dotColor, labelColor, sizeKey, annotations, dotColors,
  onSetAnnotation, onSetDotColor, panelBg, dotGlow, dotGlowRadius, todayDotGlow, todayAnim, todayAnimRadius, palette,
}: {
  months: { year: number; month: number; days: DayCell[] }[];
  dotColor: string;
  labelColor: string;
  sizeKey: SizeKey;
  annotations: Record<string, string>;
  dotColors: Record<string, string>;
  onSetAnnotation: (key: string, text: string) => void;
  onSetDotColor: (key: string, color: string | null) => void;
  panelBg: string;
  dotGlow: boolean;
  dotGlowRadius: number;
  todayDotGlow: boolean;
  todayAnim: TodayAnim;
  todayAnimRadius: number;
  palette: string[];
}) {
  const [tip, setTip] = useState<{ key: string; x: number; y: number; pinned: boolean; initial?: string } | null>(null);
  const hideTimer = useRef<number | null>(null);
  const hoveredKeyRef = useRef<string | null>(null);

  // Type-on-hover: pressing a letter while hovering a dot opens annotation prefilled
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (document.activeElement?.tagName || "").toLowerCase();
      if (tag === "input" || tag === "textarea") return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key.length !== 1) return;
      const key = hoveredKeyRef.current;
      if (!key) return;
      e.preventDefault();
      setTip({ key, x: window.innerWidth / 2, y: window.innerHeight / 2, pinned: true, initial: e.key });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  if (months.length === 0) {
    return (
      <p style={{ color: labelColor }} className="opacity-60">
        Choisissez une date dans le passé pour voir vos jours.
      </p>
    );
  }

  const dotPx = { xs: 5, sm: 6, md: 8, lg: 10, xl: 12 }[sizeKey];
  const gapPx = { xs: 3, sm: 4, md: 6, lg: 8, xl: 10 }[sizeKey];
  const labelW = { xs: 28, sm: 32, md: 38, lg: 44, xl: 50 }[sizeKey];
  const labelFs = { xs: 7, sm: 8, md: 9, lg: 10, xl: 11 }[sizeKey];
  const DOTS_ROW_WIDTH = 31 * dotPx + 30 * gapPx;
  const gMul = dotGlowRadius;

  const scheduleHide = () => {
    if (hideTimer.current) window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => setTip(null), 120);
  };
  const cancelHide = () => {
    if (hideTimer.current) { window.clearTimeout(hideTimer.current); hideTimer.current = null; }
  };

  return (
    <div className="flex justify-center w-full">
      <div className="flex flex-col mx-auto" style={{ width: "fit-content", gap: gapPx + 2 }}>
        {months.map(({ year, month, days }) => (
          <div key={`${year}-${month}`} className="flex items-center" style={{ gap: 6 }}>
            <div
              className="shrink-0 text-left tracking-wider opacity-40 select-none"
              style={{
                color: labelColor,
                fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
                width: labelW,
                fontSize: labelFs,
              }}
              title={`${MONTH_ABBR[month]} ${year}`}
            >
              {MONTH_ABBR[month]}
            </div>
            <div className="flex flex-nowrap shrink-0" style={{ width: DOTS_ROW_WIDTH, gap: gapPx }}>
              {days.map(({ day, status, dateKey }) => {
                const base: React.CSSProperties = { width: dotPx, height: dotPx };
                if (status === "empty") {
                  return <span key={day} className="block" style={base} />;
                }
                const customColor = dotColors[dateKey];
                const color = customColor ?? dotColor;
                const hasCustom = !!customColor;
                let style: React.CSSProperties;
                let extraClass = "";
                if (status === "today") {
                  style = {
                    ...base,
                    backgroundColor: color,
                    boxShadow: (dotGlow && todayDotGlow)
                      ? `0 0 ${6 * gMul}px ${color}, 0 0 ${12 * gMul}px ${color}80`
                      : "none",
                    ["--dot" as any]: color,
                    ["--anim-r" as any]: `${todayAnimRadius}px`,
                  };
                  const animClass =
                    todayAnim === "lighten" ? "today-lighten"
                    : todayAnim === "pulse" ? "today-pulse"
                    : todayAnim === "halo" ? "today-halo"
                    : "";
                  extraClass = `today-dot ${animClass}`.trim();
                } else if (status === "past") {
                  style = {
                    ...base,
                    backgroundColor: color,
                    boxShadow: (dotGlow || hasCustom)
                      ? `0 0 ${6 * gMul}px ${color}, 0 0 ${12 * gMul}px ${color}80`
                      : "none",
                  };
                } else {
                  // future
                  if (hasCustom) {
                    style = {
                      ...base,
                      backgroundColor: color,
                      boxShadow: `0 0 ${6 * gMul}px ${color}, 0 0 ${12 * gMul}px ${color}80`,
                    };
                  } else {
                    style = { ...base, backgroundColor: `${labelColor}25`, border: `1px solid ${labelColor}20` };
                  }
                }
                return (
                  <span
                    key={day}
                    className={`block rounded-full cursor-pointer ${extraClass}`}
                    style={style}
                    onMouseEnter={(e) => {
                      cancelHide();
                      hoveredKeyRef.current = dateKey;
                      setTip((prev) =>
                        prev?.pinned ? prev : { key: dateKey, x: e.clientX, y: e.clientY, pinned: false }
                      );
                    }}
                    onMouseMove={(e) => {
                      setTip((prev) => (prev && !prev.pinned && prev.key === dateKey
                        ? { ...prev, x: e.clientX, y: e.clientY } : prev));
                    }}
                    onMouseLeave={() => { hoveredKeyRef.current = null; scheduleHide(); }}
                    onClick={(e) => {
                      cancelHide();
                      setTip({ key: dateKey, x: e.clientX, y: e.clientY, pinned: true });
                    }}
                  />
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {tip && (
        <DotTooltip
          dateKey={tip.key}
          x={tip.x}
          y={tip.y}
          annotation={annotations[tip.key] ?? ""}
          dotColor={dotColors[tip.key] ?? null}
          themeText={labelColor}
          themeBg={panelBg}
          accent={dotColor}
          palette={palette}
          initial={tip.initial}
          onClose={() => setTip(null)}
          onPointerEnter={cancelHide}
          onPointerLeave={scheduleHide}
          onSaveAnnotation={(t) => onSetAnnotation(tip.key, t)}
          onSetColor={(c) => onSetDotColor(tip.key, c)}
        />
      )}
    </div>
  );
}

function DotTooltip({
  dateKey, x, y, annotation, dotColor, themeText, themeBg, accent, palette, initial,
  onClose, onPointerEnter, onPointerLeave, onSaveAnnotation, onSetColor,
}: {
  dateKey: string; x: number; y: number;
  annotation: string;
  dotColor: string | null;
  themeText: string; themeBg: string; accent: string;
  palette: string[];
  initial?: string;
  onClose: () => void;
  onPointerEnter: () => void;
  onPointerLeave: () => void;
  onSaveAnnotation: (t: string) => void;
  onSetColor: (c: string | null) => void;
}) {
  const [editing, setEditing] = useState(!!initial);
  const [text, setText] = useState(initial ? annotation + initial : annotation);
  useEffect(() => { setText(initial ? annotation + initial : annotation); setEditing(!!initial || false); /* eslint-disable-next-line */ }, [dateKey]);

  const titre = formatDateFrLong(dateKey).toUpperCase();

  const left = Math.min(x + 14, window.innerWidth - 280);
  const top = Math.min(y + 18, window.innerHeight - 200);

  const swatchColors = palette && palette.length === 6 ? palette : DEFAULT_PALETTE;

  const pipetteRef = useRef<HTMLInputElement>(null);


  return (
    <div
      className="fixed z-50 rounded-lg shadow-2xl border text-sm"
      style={{
        left, top, width: 260,
        backgroundColor: themeBg,
        color: themeText,
        borderColor: `${themeText}30`,
      }}
      onMouseEnter={onPointerEnter}
      onMouseLeave={onPointerLeave}
    >
      <div className="px-3 py-2 border-b flex items-center justify-between" style={{ borderColor: `${themeText}20` }}>
        <div className="truncate" style={{ fontSize: 9, letterSpacing: "0.05em", opacity: 0.55 }}>{titre}</div>
        <button onClick={onClose} className="opacity-60 hover:opacity-100"><X size={12} /></button>
      </div>
      <div className="px-3 py-2 space-y-2">
        {!editing && annotation && (
          <div className="text-xs whitespace-pre-wrap opacity-90">{annotation}</div>
        )}
        {editing ? (
          <>
            <textarea
              autoFocus
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={3}
              className="w-full rounded p-2 text-xs"
              style={{
                background: `${themeText}10`,
                color: themeText,
                border: `1px solid ${themeText}30`,
                resize: "vertical",
              }}
              placeholder="Votre note…"
            />
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => { setEditing(false); setText(annotation); }}
                className="text-xs px-2 py-1 rounded border"
                style={{ borderColor: `${themeText}30`, color: themeText }}
              >Annuler</button>
              <button
                onClick={() => { onSaveAnnotation(text); setEditing(false); }}
                className="text-xs px-2 py-1 rounded"
                style={{ background: accent, color: themeBg }}
              >Enregistrer</button>
            </div>
          </>
        ) : (
          <button
            onClick={() => setEditing(true)}
            className="text-xs px-2 py-1 rounded border w-full text-left opacity-80 hover:opacity-100"
            style={{ borderColor: `${themeText}25` }}
          >
            {annotation ? "Modifier l'annotation" : "Ajouter une annotation"}
          </button>
        )}

        <div className="pt-1 border-t" style={{ borderColor: `${themeText}15` }}>
          <div className="flex items-center gap-1.5 flex-wrap">
            {swatchColors.map((c) => (
              <button
                key={c}
                onClick={() => onSetColor(c)}
                className="w-4 h-4 rounded-full border"
                style={{
                  background: c,
                  borderColor: dotColor === c ? themeText : `${themeText}30`,
                }}
                title={c}
              />
            ))}
            <button
              onClick={() => pipetteRef.current?.click()}
              className="w-5 h-5 rounded flex items-center justify-center opacity-70 hover:opacity-100"
              style={{ color: themeText, border: `1px solid ${themeText}30` }}
              title="Pipette (choisir une couleur)"
            >
              <Pipette size={11} />
            </button>
            <input
              ref={pipetteRef}
              type="color"
              defaultValue={dotColor ?? "#ffffff"}
              onChange={(e) => onSetColor(e.target.value)}
              style={{ position: "absolute", width: 1, height: 1, opacity: 0 }}
              tabIndex={-1}
              aria-hidden
            />
            {dotColor && (
              <button
                onClick={() => onSetColor(null)}
                className="text-[10px] opacity-70 hover:opacity-100 underline ml-1"
              >Réinit.</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ColorInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const pipetteRef = useRef<HTMLInputElement>(null);
  return (
    <div className="flex gap-2 items-center">
      <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-10 w-full rounded border" />
      <button type="button" onClick={() => pipetteRef.current?.click()} className="btn-secondary !px-2" title="Pipette">
        <Pipette size={16} />
      </button>
      <input
        ref={pipetteRef}
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{ position: "absolute", width: 0, height: 0, opacity: 0, pointerEvents: "none" }}
      />
    </div>
  );
}


function FontPicker({
  value, onChange, sampleText, subtle, panelText, border, accent, panelBg, allowNone,
}: {
  value: string; onChange: (v: string) => void; sampleText: string;
  subtle: string; panelText: string; border: string; accent: string; panelBg: string;
  allowNone?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const options = allowNone ? ["", ...FONTS] : FONTS;
  const display = value || (allowNone ? "Aucune (par défaut)" : "System");
  return (
    <div>
      <button
        type="button" onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between input"
        style={{ backgroundColor: subtle, color: panelText, borderColor: border }}
      >
        <span style={{ fontFamily: fontCss(value) }}>{display} — {sampleText}</span>
        {open ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </button>
      {open && (
        <div className="mt-2 grid grid-cols-2 gap-2 rounded-md p-2 border" style={{ backgroundColor: subtle, borderColor: border }}>
          {options.map((f) => {
            const selected = f === value;
            const lbl = f || "Aucune";
            return (
              <button
                key={lbl} type="button"
                onClick={() => { onChange(f); setOpen(false); }}
                className="text-left px-3 py-2 rounded-md border transition hover:scale-[1.02]"
                style={{
                  fontFamily: fontCss(f),
                  backgroundColor: selected ? accent : panelBg,
                  color: selected ? panelBg : panelText,
                  borderColor: selected ? accent : border,
                }}
              >
                <div className="text-xs opacity-60" style={{ fontFamily: "system-ui, sans-serif" }}>{lbl}</div>
                <div className="text-base truncate">{sampleText}</div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function FrDateInput({
  value, onChange, subtle, panelText, border,
}: {
  value: string; onChange: (iso: string) => void;
  subtle: string; panelText: string; border: string;
}) {
  const parse = (iso: string) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || "");
    return m ? { d: m[3], mo: m[2], y: m[1] } : { d: "", mo: "", y: "" };
  };
  const [parts, setParts] = useState(parse(value));
  useEffect(() => { setParts(parse(value)); }, [value]);

  const dRef = useRef<HTMLInputElement>(null);
  const mRef = useRef<HTMLInputElement>(null);
  const yRef = useRef<HTMLInputElement>(null);

  const daysInMonth = (yStr: string, mStr: string) => {
    const y = parseInt(yStr || "2000", 10);
    const m = parseInt(mStr || "1", 10);
    return new Date(y, m, 0).getDate();
  };

  const commit = (next: { d: string; mo: string; y: string }) => {
    setParts(next);
    if (next.d.length === 2 && next.mo.length === 2 && next.y.length === 4) {
      let d = parseInt(next.d, 10);
      let m = parseInt(next.mo, 10);
      let y = parseInt(next.y, 10);
      if (isNaN(d) || isNaN(m) || isNaN(y)) return;
      m = Math.min(12, Math.max(1, m));
      y = Math.min(2100, Math.max(1900, y));
      const dim = new Date(y, m, 0).getDate();
      d = Math.min(dim, Math.max(1, d));
      const iso = `${String(y).padStart(4, "0")}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      onChange(iso);
      const clamped = { d: String(d).padStart(2, "0"), mo: String(m).padStart(2, "0"), y: String(y).padStart(4, "0") };
      if (clamped.d !== next.d || clamped.mo !== next.mo || clamped.y !== next.y) {
        setParts(clamped);
      }
    }
  };

  const onDayChange = (raw: string) => {
    const v = raw.replace(/\D/g, "").slice(0, 2);
    const next = { ...parts, d: v };
    commit(next);
    if (v.length === 2) {
      // smart clamp before move
      const dim = daysInMonth(parts.y || "2000", parts.mo || "01");
      const dn = Math.min(dim, Math.max(1, parseInt(v, 10) || 1));
      const fixed = { ...next, d: String(dn).padStart(2, "0") };
      setParts(fixed);
      mRef.current?.focus();
      mRef.current?.select();
    }
  };
  const onMonthChange = (raw: string) => {
    const v = raw.replace(/\D/g, "").slice(0, 2);
    const next = { ...parts, mo: v };
    commit(next);
    if (v.length === 2) {
      const mn = Math.min(12, Math.max(1, parseInt(v, 10) || 1));
      const fixed = { ...next, mo: String(mn).padStart(2, "0") };
      setParts(fixed);
      yRef.current?.focus();
      yRef.current?.select();
    }
  };
  const onYearChange = (raw: string) => {
    const v = raw.replace(/\D/g, "").slice(0, 4);
    const next = { ...parts, y: v };
    commit(next);
    if (v.length === 4) {
      (yRef.current as HTMLInputElement | null)?.blur();
    }
  };

  const onBlur = () => {
    if (parts.d && parts.mo && parts.y.length === 4) commit(parts);
    else setParts(parse(value));
  };

  const inputStyle: React.CSSProperties = {
    background: "transparent",
    color: panelText,
    outline: "none",
    border: "none",
    width: "2.2ch",
    textAlign: "center",
  };
  const yearStyle: React.CSSProperties = { ...inputStyle, width: "4ch" };

  return (
    <div
      className="input flex items-center justify-center gap-0"
      style={{ backgroundColor: subtle, color: panelText, borderColor: border }}
      onClick={() => { if (!parts.d) dRef.current?.focus(); }}
    >
      <input ref={dRef} inputMode="numeric" placeholder="jj" value={parts.d}
        onChange={(e) => onDayChange(e.target.value)} onBlur={onBlur}
        onFocus={(e) => e.target.select()} style={inputStyle} maxLength={2} />
      <span className="opacity-50 select-none">/</span>
      <input ref={mRef} inputMode="numeric" placeholder="mm" value={parts.mo}
        onChange={(e) => onMonthChange(e.target.value)} onBlur={onBlur}
        onFocus={(e) => e.target.select()} style={inputStyle} maxLength={2} />
      <span className="opacity-50 select-none">/</span>
      <input ref={yRef} inputMode="numeric" placeholder="aaaa" value={parts.y}
        onChange={(e) => onYearChange(e.target.value)} onBlur={onBlur}
        onFocus={(e) => e.target.select()} style={yearStyle} maxLength={4} />
    </div>
  );
}

function SizeButtons<T extends string>({
  value, options, onChange, accent, panelBg, panelText, subtle, border, cols,
}: {
  value: T;
  options: { key: T; label: string }[];
  onChange: (v: T) => void;
  accent: string; panelBg: string; panelText: string; subtle: string; border: string;
  cols?: number;
}) {
  const c = cols ?? options.length;
  return (
    <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${c}, minmax(0, 1fr))` }}>
      {options.map((o) => {
        const sel = o.key === value;
        return (
          <button
            key={o.key}
            type="button"
            onClick={() => onChange(o.key)}
            className="text-xs py-2 px-1 rounded border transition"
            style={{
              backgroundColor: sel ? accent : subtle,
              color: sel ? panelBg : panelText,
              borderColor: sel ? accent : border,
            }}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function AppleSwitch({
  checked, onChange, accent, track,
}: {
  checked: boolean; onChange: (v: boolean) => void; accent: string; track: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      style={{
        width: 40,
        height: 22,
        borderRadius: 999,
        background: checked ? accent : track,
        position: "relative",
        transition: "background 180ms ease",
        flexShrink: 0,
      }}
    >
      <span
        style={{
          position: "absolute",
          top: 2,
          left: checked ? 20 : 2,
          width: 18,
          height: 18,
          borderRadius: 999,
          background: "#fff",
          boxShadow: "0 1px 3px rgba(0,0,0,0.25)",
          transition: "left 180ms ease",
        }}
      />
    </button>
  );
}

function SettingsPanel({
  config, onChange, onClose, onReset, musicUrl, onMusicFile,
}: {
  config: Config;
  onChange: (c: Config) => void;
  onClose: () => void;
  onReset: () => void;
  musicUrl: string;
  onMusicFile: (f: File | null) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const musicRef = useRef<HTMLInputElement>(null);
  const update = <K extends keyof Config>(k: K, v: Config[K]) => onChange({ ...config, [k]: v });

  const [themesOpen, setThemesOpen] = useState(false);
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null);
  const dragRef = useRef<{ dx: number; dy: number } | null>(null);

  const handleFile = (f: File | undefined) => {
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      onChange({ ...config, bgImage: String(reader.result), useImage: true });
    };
    reader.readAsDataURL(f);
  };

  const applyTheme = (t: Theme) => {
    onChange({ ...config, bgColor: t.bgColor, textColor: t.textColor, dotColor: t.dotColor, useImage: false });
  };

  const saveCustomTheme = () => {
    const snap: ThemeSnapshot = {
      bgColor: config.bgColor, textColor: config.textColor, dotColor: config.dotColor,
      fontFamily: config.fontFamily, titleFont: config.titleFont,
      subtitleFont: config.subtitleFont, clockFont: config.clockFont,
    };
    onChange({ ...config, customTheme: snap });
  };

  const applyCustomTheme = () => {
    if (!config.customTheme) return;
    onChange({ ...config, ...config.customTheme, useImage: false });
  };

  const panelBg = config.bgColor;
  const panelText = config.textColor;
  const accent = config.dotColor;
  const subtle = `${panelText}15`;
  const border = `${panelText}25`;

  // Drag handlers
  const onHeaderMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest("button")) return;
    const rect = (e.currentTarget.parentElement as HTMLElement).getBoundingClientRect();
    dragRef.current = { dx: e.clientX - rect.left, dy: e.clientY - rect.top };
    const onMove = (ev: MouseEvent) => {
      if (!dragRef.current) return;
      setPos({ x: ev.clientX - dragRef.current.dx, y: ev.clientY - dragRef.current.dy });
    };
    const onUp = () => {
      dragRef.current = null;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const panelStyle: React.CSSProperties = pos
    ? {
        backgroundColor: panelBg, color: panelText, borderColor: border,
        position: "fixed", left: pos.x, top: pos.y, margin: 0,
      }
    : { backgroundColor: panelBg, color: panelText, borderColor: border };

  return (
    <div
      className={`fixed inset-0 z-50 ${pos ? "" : "flex items-center justify-center"}`}
      style={{ backgroundColor: "transparent" }}
      onClick={onClose}
    >
      <div
        className="rounded-xl shadow-2xl w-[92vw] max-w-xl max-h-[90vh] flex flex-col border"
        style={panelStyle}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="flex items-center justify-between px-5 py-3 border-b shrink-0 rounded-t-xl select-none"
          style={{ borderColor: border, backgroundColor: panelBg, cursor: "move" }}
          onMouseDown={onHeaderMouseDown}
        >
          <h2 className="text-lg font-semibold">Paramètres</h2>
          <button onClick={onClose} className="p-1 rounded hover:opacity-70"><X size={18} /></button>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto no-scrollbar flex-1">
          {/* Themes (collapsible) */}
          <div>
            <button
              type="button"
              onClick={() => setThemesOpen((o) => !o)}
              className="flex items-center gap-1 text-sm font-medium mb-2 opacity-80"
            >
              <span>Thèmes prédéfinis</span>
              {themesOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
            <div
              className="overflow-hidden transition-all duration-300 ease-out"
              style={{
                maxHeight: themesOpen ? 1600 : 0,
                opacity: themesOpen ? 1 : 0,
              }}
            >
              <div className="grid grid-cols-3 gap-2 pt-1">
                {THEMES.map((t) => (
                  <button
                    key={t.name}
                    onClick={() => applyTheme(t)}
                    className="theme-tile rounded-lg p-2 border text-left"
                    style={{
                      backgroundColor: t.bgColor,
                      color: t.textColor,
                      borderColor:
                        config.bgColor === t.bgColor && config.dotColor === t.dotColor
                          ? t.dotColor : `${t.textColor}30`,
                      borderWidth: 2,
                    }}
                    title={t.name}
                  >
                    <div className="flex gap-1 mb-1">
                      {[0, 1, 2, 3, 4].map((i) => (
                        <span key={i} className="block rounded-full"
                          style={{ width: 6, height: 6, backgroundColor: t.dotColor, boxShadow: `0 0 4px ${t.dotColor}` }} />
                      ))}
                    </div>
                    <div className="text-[10px] truncate opacity-80">{t.name}</div>
                  </button>
                ))}
                {/* Legacy single custom slot */}
                {[config.customTheme, ...(config.customThemes ?? [null, null, null])].map((ct, idx) => (
                  <button
                    key={`custom-${idx}`}
                    onClick={() => {
                      if (!ct) return;
                      onChange({ ...config, ...ct, useImage: false });
                    }}
                    disabled={!ct}
                    className="theme-tile rounded-lg p-2 border text-left disabled:opacity-40 disabled:cursor-not-allowed relative group"
                    style={{
                      backgroundColor: ct?.bgColor ?? subtle,
                      color: ct?.textColor ?? panelText,
                      borderColor: ct?.dotColor ?? border,
                      borderWidth: 2,
                    }}
                    title={ct ? `Thème perso ${idx + 1}` : `Slot perso ${idx + 1} (vide)`}
                  >
                    <div className="flex gap-1 mb-1">
                      {[0, 1, 2, 3, 4].map((i) => (
                        <span key={i} className="block rounded-full"
                          style={{ width: 6, height: 6, backgroundColor: ct?.dotColor ?? `${panelText}40` }} />
                      ))}
                    </div>
                    <div className="text-[10px] truncate opacity-80">
                      {ct ? `Perso ${idx + 1}` : "Vide"}
                    </div>
                    {ct && (
                      <span
                        role="button"
                        aria-label="Écraser"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!confirm(`Écraser le thème perso ${idx + 1} avec le thème actuel ?`)) return;
                          const snap: ThemeSnapshot = {
                            bgColor: config.bgColor, textColor: config.textColor, dotColor: config.dotColor,
                            fontFamily: config.fontFamily, titleFont: config.titleFont,
                            subtitleFont: config.subtitleFont, clockFont: config.clockFont,
                          };
                          if (idx === 0) onChange({ ...config, customTheme: snap });
                          else {
                            const arr = [...(config.customThemes ?? [null, null, null])];
                            arr[idx - 1] = snap;
                            onChange({ ...config, customThemes: arr });
                          }
                        }}
                        className="absolute top-1 right-1 opacity-0 group-hover:opacity-80 text-[9px] px-1 rounded"
                        style={{ background: `${panelText}30`, color: panelText }}
                      >
                        ↻
                      </span>
                    )}
                  </button>
                ))}
              </div>
              <div className="mt-2 flex justify-end">
                <button onClick={() => {
                  const snap: ThemeSnapshot = {
                    bgColor: config.bgColor, textColor: config.textColor, dotColor: config.dotColor,
                    fontFamily: config.fontFamily, titleFont: config.titleFont,
                    subtitleFont: config.subtitleFont, clockFont: config.clockFont,
                  };
                  // Save into first empty slot, or replace customTheme
                  const slots = config.customThemes ?? [null, null, null];
                  if (!config.customTheme) {
                    onChange({ ...config, customTheme: snap });
                  } else {
                    const emptyIdx = slots.findIndex((s) => !s);
                    if (emptyIdx >= 0) {
                      const arr = [...slots];
                      arr[emptyIdx] = snap;
                      onChange({ ...config, customThemes: arr });
                    } else {
                      onChange({ ...config, customTheme: snap });
                    }
                  }
                }} className="btn-secondary text-xs flex items-center gap-1.5"
                  style={{ backgroundColor: subtle, color: panelText, borderColor: border }}>
                  <Save size={13} /> Enregistrer le thème
                </button>
              </div>
            </div>
          </div>

          {/* Mode toggle: 2 buttons */}
          <Field label="Mode d'affichage">
            <div className="grid grid-cols-2 gap-1.5">
              {([
                { key: "dots", label: "Dots lumineux" },
                { key: "counter", label: "Compteur de jours" },
              ] as { key: Mode; label: string }[]).map((o) => {
                const sel = o.key === config.mode;
                return (
                  <button
                    key={o.key}
                    type="button"
                    onClick={() => update("mode", o.key)}
                    className="text-xs py-2 px-1 rounded border transition"
                    style={{
                      backgroundColor: sel ? accent : subtle,
                      color: sel ? panelBg : panelText,
                      borderColor: sel ? accent : border,
                    }}
                  >
                    {o.label}
                  </button>
                );
              })}
            </div>
          </Field>

          {/* Size: calendar OR counter text */}
          {config.mode === "dots" ? (
            <Field label="Taille du calendrier (points)">
              <SizeButtons
                value={config.calendarSize}
                options={SIZE_LABELS}
                onChange={(v) => update("calendarSize", v)}
                accent={accent} panelBg={panelBg} panelText={panelText} subtle={subtle} border={border}
              />
            </Field>
          ) : (
            <Field label="Taille du texte du message">
              <SizeButtons
                value={config.counterTextSize}
                options={SIZE_LABELS}
                onChange={(v) => update("counterTextSize", v)}
                accent={accent} panelBg={panelBg} panelText={panelText} subtle={subtle} border={border}
              />
            </Field>
          )}

          <Field label="Taille du bloc (titre, sous-titre, barre)">
            <SizeButtons
              value={config.blockSize}
              options={SIZE_LABELS}
              onChange={(v) => update("blockSize", v)}
              accent={accent} panelBg={panelBg} panelText={panelText} subtle={subtle} border={border}
            />
          </Field>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Date de début">
              <FrDateInput value={config.refDate} onChange={(v) => update("refDate", v)}
                subtle={subtle} panelText={panelText} border={border} />
            </Field>
            <Field label="Date de fin">
              <FrDateInput value={config.endDate} onChange={(v) => update("endDate", v)}
                subtle={subtle} panelText={panelText} border={border} />
            </Field>
          </div>

          <Field label="Titre">
            <input type="text" value={config.title} onChange={(e) => update("title", e.target.value)} className="input"
              style={{ backgroundColor: subtle, color: panelText, borderColor: border }} />
          </Field>

          {/* Title Glow */}
          <Field label="">
            <div className="flex items-center justify-between">
              <span className="text-sm opacity-80">Glow du titre</span>
              <AppleSwitch checked={config.titleGlow} onChange={(v) => update("titleGlow", v)} accent={accent} track={subtle} />
            </div>
            {config.titleGlow && (
              <div className="mt-2 space-y-2">
                <div>
                  <label className="block text-xs opacity-70 mb-1">Rayon : {config.titleGlowRadius}px</label>
                  <input type="range" min={0} max={40} value={config.titleGlowRadius}
                    onChange={(e) => update("titleGlowRadius", Number(e.target.value))}
                    className="w-full slider-mono" />
                </div>
                <div>
                  <label className="block text-xs opacity-70 mb-1">Couleur du glow</label>
                  <ColorInput value={config.titleGlowColor} onChange={(v) => update("titleGlowColor", v)} />
                </div>
              </div>
            )}
          </Field>

          <Field label="Police du titre">
            <FontPicker value={config.titleFont} onChange={(v) => update("titleFont", v)}
              sampleText={config.title || "Aa Bb Cc"}
              subtle={subtle} panelText={panelText} border={border} accent={accent} panelBg={panelBg} />
          </Field>
          <Field label="Sous-titre">
            <input type="text" value={config.subtitle} onChange={(e) => update("subtitle", e.target.value)} className="input"
              style={{ backgroundColor: subtle, color: panelText, borderColor: border }} />
          </Field>
          <Field label="Police du sous-titre">
            <FontPicker value={config.subtitleFont} onChange={(v) => update("subtitleFont", v)}
              sampleText={config.subtitle || "Aa Bb Cc"}
              subtle={subtle} panelText={panelText} border={border} accent={accent} panelBg={panelBg} />
          </Field>

          <Field label="Animation du sous-titre">
            <div className="grid grid-cols-4 gap-1.5">
              {SUBTITLE_ANIM_OPTIONS.map((o) => {
                const sel = o.key === config.subtitleAnim;
                return (
                  <button key={o.key} type="button"
                    onClick={() => update("subtitleAnim", o.key)}
                    className="text-xs py-2 px-1 rounded border transition"
                    style={{
                      backgroundColor: sel ? accent : subtle,
                      color: sel ? panelBg : panelText,
                      borderColor: sel ? accent : border,
                    }}>
                    {o.label}
                  </button>
                );
              })}
            </div>
          </Field>

          <Field label="Palette d'annotation (6 couleurs)">
            <div className="flex gap-2 flex-wrap">
              {(config.annotationPalette ?? DEFAULT_PALETTE).map((c, i) => (
                <label key={i} className="relative cursor-pointer">
                  <span className="block w-8 h-8 rounded-full border" style={{ background: c, borderColor: border }} />
                  <input type="color" value={c}
                    onChange={(e) => {
                      const arr = [...(config.annotationPalette ?? DEFAULT_PALETTE)];
                      arr[i] = e.target.value;
                      update("annotationPalette", arr);
                    }}
                    style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0, cursor: "pointer" }}
                  />
                </label>
              ))}
              <button type="button" onClick={() => update("annotationPalette", [...DEFAULT_PALETTE])}
                className="text-xs underline opacity-60 hover:opacity-100">Réinit.</button>
            </div>
          </Field>


          {/* Date du jour */}
          <Field label="">
            <div className="flex items-center justify-between">
              <span className="text-sm opacity-80">Afficher la date du jour</span>
              <AppleSwitch checked={config.showDate} onChange={(v) => update("showDate", v)} accent={accent} track={subtle} />
            </div>
            {config.showDate && (
              <div className="mt-2 space-y-2">
                <FontPicker value={config.dateFont} onChange={(v) => update("dateFont", v)}
                  sampleText="lundi 8 juin 2026"
                  subtle={subtle} panelText={panelText} border={border} accent={accent} panelBg={panelBg} />
                <SizeButtons
                  value={config.dateSize}
                  options={SIZE_LABELS}
                  onChange={(v) => update("dateSize", v)}
                  accent={accent} panelBg={panelBg} panelText={panelText} subtle={subtle} border={border}
                />
              </div>
            )}
          </Field>

          <Field label="Police de l'heure">
            <FontPicker value={config.clockFont} onChange={(v) => update("clockFont", v)}
              sampleText="12:34:56"
              subtle={subtle} panelText={panelText} border={border} accent={accent} panelBg={panelBg} />
          </Field>

          <Field label="Police de la barre de progression">
            <FontPicker value={config.progressFont} onChange={(v) => update("progressFont", v)}
              sampleText="90 jours écoulés"
              subtle={subtle} panelText={panelText} border={border} accent={accent} panelBg={panelBg} />
          </Field>

          <Field label="Police générale (écrase toutes les polices)">
            <FontPicker
              value={config.generalFont}
              onChange={(v) => {
                if (v) {
                  onChange({
                    ...config,
                    generalFont: v,
                    fontFamily: v,
                    titleFont: v,
                    subtitleFont: v,
                    clockFont: v,
                    progressFont: v,
                    dateFont: v,
                  });
                } else {
                  update("generalFont", v);
                }
              }}
              sampleText="Aa Bb Cc 123"
              subtle={subtle} panelText={panelText} border={border} accent={accent} panelBg={panelBg}
              allowNone />
          </Field>

          {config.mode === "counter" && (
            <Field label="Message (utilisez {jours})">
              <textarea value={config.template} onChange={(e) => update("template", e.target.value)} rows={2}
                className="input resize-none"
                style={{ backgroundColor: subtle, color: panelText, borderColor: border }} />
            </Field>
          )}

          <div className="grid grid-cols-2 gap-4">
            <Field label="Couleur de fond">
              <ColorInput value={config.bgColor} onChange={(v) => update("bgColor", v)} />
            </Field>
            <Field label="Couleur du texte">
              <ColorInput value={config.textColor} onChange={(v) => update("textColor", v)} />
            </Field>
          </div>

          {config.mode === "dots" && (
            <>
              <Field label="Couleur des points">
                <ColorInput value={config.dotColor} onChange={(v) => update("dotColor", v)} />
              </Field>

              {/* Dot glow */}
              <Field label="">
                <div className="flex items-center justify-between">
                  <span className="text-sm opacity-80">Glow des points</span>
                  <AppleSwitch checked={config.dotGlow} onChange={(v) => update("dotGlow", v)} accent={accent} track={subtle} />
                </div>
                {config.dotGlow && (
                  <div className="mt-2">
                    <label className="block text-xs opacity-70 mb-1">Rayon : {config.dotGlowRadius.toFixed(2)}×</label>
                    <input type="range" min={0.3} max={2} step={0.05} value={config.dotGlowRadius}
                      onChange={(e) => update("dotGlowRadius", Number(e.target.value))}
                      className="w-full slider-mono" />
                  </div>
                )}
              </Field>

              {/* Glow du jour */}
              <Field label="">
                <div className="flex items-center justify-between">
                  <span className="text-sm opacity-80">Glow du dot du jour</span>
                  <AppleSwitch checked={config.todayDotGlow} onChange={(v) => update("todayDotGlow", v)} accent={accent} track={subtle} />
                </div>
              </Field>

              {/* Animation du dot du jour */}
              <Field label="Animation du dot du jour">
                <div className="grid grid-cols-4 gap-1.5">
                  {TODAY_ANIM_OPTIONS.map((o) => {
                    const sel = o.key === config.todayAnim;
                    return (
                      <button
                        key={o.key}
                        type="button"
                        onClick={() => update("todayAnim", o.key)}
                        className="text-xs py-2 px-1 rounded border transition"
                        style={{
                          backgroundColor: sel ? accent : subtle,
                          color: sel ? panelBg : panelText,
                          borderColor: sel ? accent : border,
                        }}
                      >
                        {o.label}
                      </button>
                    );
                  })}
                </div>
                {config.todayAnim !== "off" && (
                  <div className="mt-2">
                    <label className="block text-xs opacity-70 mb-1">Rayon de l'animation : {config.todayAnimRadius}px</label>
                    <input type="range" min={1} max={12} value={config.todayAnimRadius}
                      onChange={(e) => update("todayAnimRadius", Number(e.target.value))}
                      className="w-full slider-mono" />
                  </div>
                )}
              </Field>
            </>
          )}

          <Field label="Barre de progression">
            <button
              onClick={() => update("progressGradient", !config.progressGradient)}
              className="btn-secondary"
              style={{ backgroundColor: subtle, color: panelText, borderColor: border }}
            >
              Mode actuel : {config.progressGradient ? "Dégradé" : "Net"} — cliquer pour basculer
            </button>
          </Field>

          {/* Image de fond */}
          <Field label="">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium opacity-80 flex items-center gap-2">
                <ImageIcon size={14} /> Image de fond
              </span>
              <AppleSwitch checked={config.useImage} onChange={(v) => update("useImage", v)} accent={accent} track={subtle} />
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={() => fileRef.current?.click()}
                className="btn flex items-center gap-2"
                style={{ backgroundColor: accent, color: panelBg }}>
                <ImageIcon size={14} /> Ajouter une image de fond
              </button>
              {config.bgImage && (
                <button type="button" onClick={() => update("bgImage", "")} className="btn-secondary"
                  style={{ backgroundColor: subtle, color: panelText, borderColor: border }}>Retirer</button>
              )}
              <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
            </div>
            {config.useImage && config.bgImage && (
              <div className="mt-3">
                <label className="block text-xs opacity-70 mb-1">Flou : {config.bgImageBlur}px</label>
                <input
                  type="range" min={0} max={20} value={config.bgImageBlur}
                  onChange={(e) => update("bgImageBlur", Number(e.target.value))}
                  className="w-full"
                />
              </div>
            )}
          </Field>

          {/* Musique de fond */}
          <Field label="">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium opacity-80 flex items-center gap-2">
                <Music size={14} /> Musique de fond (MP3)
              </span>
              <AppleSwitch
                checked={config.bgMusicEnabled}
                onChange={(v) => update("bgMusicEnabled", v)}
                accent={accent} track={subtle}
              />
            </div>
            <div className="flex gap-2 items-center">
              <button type="button" onClick={() => musicRef.current?.click()}
                className="btn flex items-center gap-2"
                style={{ backgroundColor: accent, color: panelBg }}>
                <Music size={16} /> Ajouter une musique de fond
              </button>
              {musicUrl && (
                <button type="button" onClick={() => onMusicFile(null)} className="btn-secondary"
                  style={{ backgroundColor: subtle, color: panelText, borderColor: border }}>Retirer</button>
              )}
              <input ref={musicRef} type="file" accept="audio/*" hidden
                onChange={(e) => onMusicFile(e.target.files?.[0] ?? null)} />
            </div>
            {config.bgMusicName && (
              <p className="text-xs opacity-60 mt-1">
                {musicUrl ? `♪ ${config.bgMusicName} — lecture en boucle` : `Fichier précédent : ${config.bgMusicName} (re-sélectionnez pour relire)`}
              </p>
            )}
          </Field>

          {config.mode === "counter" && (
            <>
              <Field label="Police du message">
                <FontPicker value={config.fontFamily} onChange={(v) => update("fontFamily", v)}
                  sampleText="Aa Bb Cc 123"
                  subtle={subtle} panelText={panelText} border={border} accent={accent} panelBg={panelBg} />
              </Field>
              <Field label={`Taille de police : ${config.fontSize}px`}>
                <input type="range" min={8} max={200} value={config.fontSize}
                  onChange={(e) => update("fontSize", Number(e.target.value))} className="w-full" />
              </Field>
              <div className="flex gap-4">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={config.bold} onChange={(e) => update("bold", e.target.checked)} />
                  <span>Gras</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={config.italic} onChange={(e) => update("italic", e.target.checked)} />
                  <span>Italique</span>
                </label>
              </div>
            </>
          )}
        </div>

        <div
          className="flex justify-between px-5 py-3 border-t rounded-b-xl shrink-0"
          style={{ borderColor: border, backgroundColor: panelBg }}
        >
          <button onClick={onReset} className="btn-secondary"
            style={{ backgroundColor: subtle, color: panelText, borderColor: border }}>
            Réinitialiser
          </button>
          <button onClick={onClose} className="btn" style={{ backgroundColor: accent, color: panelBg }}>
            Fermer
          </button>
        </div>
      </div>

      <style>{`
        .no-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
        .no-scrollbar::-webkit-scrollbar { width: 0; height: 0; display: none; }
        .input { width: 100%; padding: 0.5rem 0.75rem; border: 1px solid; border-radius: 0.375rem; font-size: 0.875rem; }
        .input:focus { outline: 2px solid currentColor; outline-offset: -1px; }
        .btn { padding: 0.5rem 1rem; border-radius: 0.375rem; font-size: 0.875rem; font-weight: 600; transition: opacity .15s; }
        .btn:hover { opacity: 0.85; }
        .btn-secondary { padding: 0.5rem 1rem; border: 1px solid; border-radius: 0.375rem; font-size: 0.875rem; font-weight: 500; transition: opacity .15s; }
        .btn-secondary:hover { opacity: 0.85; }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      {label && <label className="block text-sm font-medium mb-1 opacity-80">{label}</label>}
      {children}
    </div>
  );
}
